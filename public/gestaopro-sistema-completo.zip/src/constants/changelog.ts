export type ChangeCategory = 'Adicionado' | 'Corrigido' | 'Alterado' | 'Segurança' | 'Removido';

export interface ChangelogItem {
  category: ChangeCategory;
  description: string;
}

export interface ChangelogEntry {
  version: string;
  date: string;
  title: string;
  summary: string;
  highlights: string[];
  changes: ChangelogItem[];
}

export const SYSTEM_CHANGELOG: ChangelogEntry[] = [
  {
    version: 'v2.7.22',
    date: '22/11/2026',
    title: 'Importação de Estoque Etapa 1: Conciliação De-Para, Conversão de Unidades, Rateio e Duplicatas NF-e',
    summary:
      'Evolução completa do motor de importação de estoque (NF-e XML e Importação Universal CSV/XLSX/TXT/XML/SQL/PDF) com conciliação automática De-Para, memória por fornecedor, fator de conversão de unidades, rateio de frete/seguro/outras despesas/descontos, política de custo na unidade do estoque e integração financeira seletiva com leitura de duplicatas do XML.',
    highlights: [
      'Detecção Automática ("De-Para") & Sugestão Inteligente: conciliação por EAN/GTIN exato, vínculo memorizado por fornecedor + código/descrição (pré-preenchendo o último fator de conversão) e busca aproximada por similaridade',
      'Pré-Visualização com Comparação Lado a Lado & Fator de Conversão: ação por linha (Vincular Existente preservando nome padrão, Cadastrar Novo ou Ignorar), fator decimal editável, conversão de unidade (ex.: CX → UN), quantidade convertida e custo unitário efetivo em tempo real',
      'Rateio da NF-e & Política de Custo: extração e ajuste manual de vProd, vFrete, vSeg, vOutro, vDesc e vNF com rateio proporcional ao valor, à quantidade ou apenas no financeiro, além de escolha entre último custo efetivo, Custo Médio Ponderado ou manter custo atual',
      'Integração Financeira Seletiva & Duplicatas XML: padrão sem lançamento financeiro, criação automática a partir de <cobr>/<dup> e <pag>/<detPag> com parcelas editáveis e atalhos rápidos (À vista, 7d, 14d, 28d, 30d, X parcelas), ou vínculo bidirecional com despesa já existente sem duplicar valores'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Motor de conciliação De-Para (EAN/GTIN exato, vínculo memorizado por fornecedor, código/SKU e similaridade de descrição) com comparação visual lado a lado e memorização automática do vínculo e fator de conversão para compras futuras.'
      },
      {
        category: 'Adicionado',
        description:
          'Fator de conversão decimal por item (Unidade do Fornecedor → Unidade do Estoque) com cálculo em tempo real de quantidade convertida e custo unitário efetivo convertido na NF-e XML e na Importação Universal.'
      },
      {
        category: 'Adicionado',
        description:
          'Leitura de <total>/<ICMSTot> (vProd, vFrete, vSeg, vOutro, vDesc, vNF), critérios de rateio configuráveis (valor, quantidade ou apenas financeiro) e políticas de atualização de custo (custo efetivo convertido, Custo Médio Ponderado ou manter custo atual).'
      },
      {
        category: 'Adicionado',
        description:
          'Integração financeira seletiva com 3 modos (Não gerar, Gerar nova Despesa lendo duplicatas <cobr>/<dup> e <pag>/<detPag> com parcelas editáveis e atalhos rápidos, ou Vincular a Despesa existente com rastreabilidade bidirecional sem duplicar valores).'
      }
    ]
  },
  {
    version: 'v2.7.21',
    date: '21/11/2026',
    title: 'Ordens de Serviço: Campo Opcional de Referência do Contrato',
    summary:
      'Adicionado campo opcional "Referência do Contrato" nas Ordens de Serviço (criação, edição, busca, listagem, cards, detalhes e impressão/PDF A4), exibido automaticamente sempre que houver um contrato vinculado.',
    highlights: [
      'Campo Opcional na Abertura e Edição de O.S.: registre número ou identificação de contrato (ex.: Contrato nº 045/2026, Manutenção Mensal) com botão rápido de limpeza',
      'Busca, Listagem, Cards & Detalhes: pesquise Ordens de Serviço pela referência do contrato e visualize o vínculo na tabela, nos cards, no tooltip e no modal de detalhes',
      'Impressão & PDF A4: quando preenchida, a Referência do Contrato sai impressa automaticamente no quadro Prazos e Responsável do documento oficial da O.S.'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Campo opcional "Referência do Contrato" (contractReference) no formulário de criação/edição de Ordens de Serviço, nos filtros/busca ao vivo, na listagem, nos cards, no modal de detalhes e nos modelos de impressão A4.'
      }
    ]
  },
  {
    version: 'v2.7.20',
    date: '21/11/2026',
    title: 'Manual do Sistema, Ajuda Rápida & Documentação Técnica Atualizados (18 Capítulos)',
    summary:
      'Atualização completa de todos os manuais internos do FIRE GESTÃO (Manual Operacional com novo Capítulo 18, Ajuda Rápida por Módulo e Especificação Técnica) incorporando todas as novas funcionalidades recentes e removendo referências desatualizadas.',
    highlights: [
      'Manual Operacional Expandido (18 Capítulos): inclusão do Capítulo 18 dedicado à Arquitetura Modular (ativar/desativar módulos) e atualização dos capítulos de OS, Financeiro/DRE, Importação Seletiva e Configurações',
      'OS, Importação Seletiva & Temas Documentados: passo a passo claro do Atalho Cadastrar Cliente na OS, Fotos de Início (Antes) e Local de Entrega, Importação Somente Produtos sem Financeiro (NF-e XML, Planilhas e Backup JSON) e os 2 temas oficiais FIRE GESTÃO',
      'Ajuda Rápida & Especificação Técnica Sincronizadas: atualização dos módulos MOD-1.1, MOD-1.2, MOD-1.4, MOD-2.6, MOD-3.3, MOD-4.4, MOD-4.5, MOD-6.1, MOD-6.2, novo MOD-4.7 e revisão do modal técnico'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Novo Capítulo 18 no Manual Operacional e novo módulo MOD-4.7 na Ajuda Rápida explicando a Arquitetura Modular (pasta modulos, ativarModulos.ts e Configurações → Módulos do Sistema) e o cabeçalho limpo sem seletor de data/mês.'
      },
      {
        category: 'Alterado',
        description:
          'Atualizados os capítulos e módulos de Ordens de Serviço (Atalho Cadastrar Cliente com CEP/CNPJ e Registro Fotográfico de Início/Entrega com câmera ao vivo, galeria e impressão A4), Importação Seletiva (Somente Produtos sem Financeiro na NF-e XML, Importação Universal e Backup JSON) e Financeiro/DRE (Zero Absoluto e DRE reconciliado).'
      },
      {
        category: 'Alterado',
        description:
          'Removidas referências antigas a temas descontinuados e dados de exemplo em todos os manuais e na Especificação Técnica, refletindo os 2 temas oficiais (Fire Gestão · Chama Alegre e Azul Cobalto) e a nova tela de login solar.'
      }
    ]
  },
  {
    version: 'v2.7.19',
    date: '21/11/2026',
    title: 'Ordens de Serviço: Atalho de Cadastro Rápido de Cliente & Fotos de Início e Local de Entrega',
    summary:
      'Adicionado atalho direto na tela de Ordens de Serviço (cabeçalho e formulário da OS) para cadastrar novos clientes sem sair do atendimento, e novo painel fotográfico integrado com câmera ao vivo e galeria para registrar fotos do início (antes dos serviços) e do local de entrega.',
    highlights: [
      'Atalho Cadastrar Cliente na OS: botão no topo da tela de Ordens de Serviço e ao lado do campo Cliente no formulário, com consulta automática de CEP/CNPJ e seleção imediata do cliente recém-cadastrado',
      'Fotos do Início (Antes dos Serviços) & Local de Entrega: câmera ao vivo (com inversão frontal/traseira e fallback nativo no celular) + envio da galeria com compressão automática e ampliação em tela cheia',
      'Acesso Rápido & Impressão A4: botão de câmera direto em cada linha/card da lista, painel interativo nos detalhes da OS com salvamento imediato e exibição das fotos no documento oficial A4'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Atalho "Cadastrar Cliente" no cabeçalho de Ordens de Serviço e botão "+ Cadastrar Cliente" junto ao seletor de cliente na abertura/edição de OS, abrindo modal de cadastro rápido com busca de CEP e CNPJ.'
      },
      {
        category: 'Adicionado',
        description:
          'Painel de Registro Fotográfico da OS separado em "Início — Antes de Começar os Serviços" e "Local de Entrega dos Serviços", com captura direta pela câmera ao vivo, câmera nativa do celular ou galeria e visualização em tela cheia.'
      },
      {
        category: 'Alterado',
        description:
          'Removidas fotos fictícias automáticas na criação de OS e adicionada seção de Registro Fotográfico (Início & Entrega) na visualização/impressão A4 da Ordem de Serviço.'
      }
    ]
  },
  {
    version: 'v2.7.18',
    date: '19/11/2026',
    title: 'Importação Seletiva Completa (Cadastrar Somente Produtos sem Enviar ao Financeiro)',
    summary:
      'Controle granular de importação em todas as centrais do FIRE GESTÃO (NF-e XML, Importação Universal CSV/Excel/TXT/XML/SQL/PDF e Restauração de Backup JSON), permitindo importar apenas os dados desejados — inclusive cadastrar somente produtos no catálogo sem gerar nenhum lançamento no Financeiro/DRE.',
    highlights: [
      'NF-e XML Seletiva: escolha em 1 clique "Somente Cadastrar Produtos (Sem Financeiro)", marque/desmarque cada item da nota, controle se soma no estoque, se cadastra fornecedor e se lança no Contas a Pagar (desmarcado por padrão)',
      'Importação Universal Seletiva: marque linha a linha quais registros importar, com painel exclusivo para Produtos garantindo isolamento total do Financeiro e opções de zerar estoque inicial ou custo',
      'Restauração de Backup JSON Seletiva: carregue um arquivo .json ou cole o backup, veja a contagem por módulo e selecione exatamente o que importar (com atalho "Somente Produtos (Sem Financeiro)")'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Painel de Importação Seletiva na conferência de NF-e XML com atalhos rápidos ("Somente Cadastrar Produtos (Sem Financeiro)", "Produtos + Estoque (Sem Financeiro)" e "Importação Completa"), checkboxes independentes por ação e seleção individual de cada produto da nota.'
      },
      {
        category: 'Alterado',
        description:
          'Na importação de XML NF-e, o lançamento automático no Financeiro (Contas a Pagar / DRE) passou a iniciar desmarcado por segurança, evitando qualquer impacto financeiro indesejado.'
      },
      {
        category: 'Adicionado',
        description:
          'Na Importação Universal (CSV/XLSX/TXT/XML/SQL/PDF), adicionada seleção linha a linha na tabela de conferência e opções exclusivas para Produtos (cadastro 100% isolado do Financeiro, opção de estoque inicial zerado e controle de custo/preços de venda).'
      },
      {
        category: 'Adicionado',
        description:
          'Na aba Configurações → Backup & Restauração, adicionada restauração seletiva por categoria (11 módulos independentes com contagem prévia do JSON, upload de arquivo .json e atalho "Somente Produtos (Sem Financeiro)").'
      }
    ]
  },
  {
    version: 'v2.7.17',
    date: '18/11/2026',
    title: 'Arquitetura Modular (Pasta modulos + Controle de Ativação) e Topo Limpo sem Seletor de Data/Mês',
    summary:
      'Reorganização completa de todos os 22 módulos do FIRE GESTÃO dentro da pasta dedicada modulos com arquivo central para ativar/desativar módulos (true/false), painel visual de gestão de módulos em Configurações e remoção do campo de data/mês do cabeçalho superior.',
    highlights: [
      'Pasta modulos Organizada: todos os 22 módulos do sistema separados em pastas próprias dentro de src/modulos/ junto ao índice central e ao arquivo ativarModulos.ts',
      'Ativação e Desativação em 1 Arquivo: altere qualquer módulo para true ou false em src/modulos/ativarModulos.ts (ou em tempo real na aba Configurações → Módulos do Sistema) para exibir ou ocultar o módulo do menu, atalhos e rotas',
      'Topo Mais Limpo: remoção definitiva do campo de data/mês do cabeçalho superior do sistema'
    ],
    changes: [
      {
        category: 'Removido',
        description:
          'Removido o campo de seleção de data e mês do topo (Header) do sistema.'
      },
      {
        category: 'Alterado',
        description:
          'Todos os 22 módulos (Dashboard, Agenda, PDV, Ordens de Serviço, Vendas, Portal do Cliente, Financeiro/DRE, Gráficos BI, Lucratividade, Fechamento Fiscal, Custos Fixos, Frota, Custos Iniciais, Cadastros, Operadoras, Estoque, Clientes, Fornecedores, Funcionários, Google Drive, Configurações e Manual) foram organizados dentro da pasta src/modulos/.'
      },
      {
        category: 'Adicionado',
        description:
          'Criado o arquivo central src/modulos/ativarModulos.ts (com chave mestra true/false por módulo) e a nova aba Configurações → Módulos do Sistema para ativar ou desativar módulos dinamicamente.'
      }
    ]
  },
  {
    version: 'v2.7.16',
    date: '18/11/2026',
    title: 'Nova Identidade FIRE GESTÃO, Favicon Chama Alegre, Login Solar & Temas Enxutos',
    summary:
      'Renomeação oficial do sistema para FIRE GESTÃO, criação do favicon em vetor de mini chama amarela e laranja, reformulação completa da tela de login nas cores alegres da chama e reorganização dos temas para apenas 2 opções: o novo tema oficial Fire Gestão · Chama Alegre e o tema Azul Cobalto.',
    highlights: [
      'Favicon Mini Chama (Amarelo + Laranja): ícone vetorial nítido na aba do navegador e identidade visual aplicada no cabeçalho e na tela de login',
      'Identidade FIRE GESTÃO: renomeação unificada no título, cabeçalho, login, rodapé, portal do cliente, recibos PDF, manuais e documentos exportados',
      'Tela de Login nas Cores do Favicon: visual alegre e luminoso combinando amarelo solar e laranja vibrante com alta legibilidade',
      'Temas Enxutos e Harmoniosos: remoção dos temas antigos (Clássico, Terracota, Terra & Oliva e Claro Ouro), mantendo apenas Azul Cobalto e o novo tema Fire Gestão · Chama Alegre (laranja, amarelo, verde petróleo, esmeralda e marfim suave)'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Adicionado favicon vetorial oficial em mini chama unindo amarelo solar e laranja vibrante, replicado como ícone da marca na tela de login e no cabeçalho do sistema.'
      },
      {
        category: 'Alterado',
        description:
          'Sistema renomeado para FIRE GESTÃO em todo o aplicativo (título da aba, tela de login, cabeçalho, rodapé, portal do cliente, recibos, fechamentos, manuais e migração automática de nomes padrão antigos).'
      },
      {
        category: 'Alterado',
        description:
          'Tela de login totalmente redesenhada nas cores alegres do favicon (amarelo solar + laranja chama sobre fundo iluminado), com cartão limpo e alto contraste.'
      },
      {
        category: 'Removido',
        description:
          'Removidos os temas pré-instalados anteriores (Clássico, Terracota & Ardósia Mineral, Terra & Oliva e Claro & Suave), preservando o tema Azul Cobalto e adicionando o novo tema oficial Fire Gestão · Chama Alegre como padrão.'
      }
    ]
  },
  {
    version: 'v2.7.15',
    date: '18/11/2026',
    title: 'Zero Absoluto + Revisão Geral do DRE e de Todos os Demonstrativos Financeiros',
    summary:
      'Limpeza total de todos os dados pré-alimentados e valores fictícios em todo o sistema (localStorage, Firestore e telas), garantindo partida do zero absoluto (R$ 0,00) com apenas a conta admin preservada, somada a uma auditoria completa e correção de todas as fórmulas do DRE, Dashboard, Gráficos BI, Fechamento Contábil, Rentabilidade por Funcionário e Simuladores.',
    highlights: [
      'Zero Absoluto Real: remoção de todos os funcionários, investimentos, custos, históricos fictícios (2024/2025), logs iniciais, botões de exemplo e limpeza automática de coleções legadas no localStorage e Firestore',
      'DRE 100% Reconciliado (Centavo por Centavo): rateio proporcional de descontos em O.S. (elimina receita negativa de serviços), inclusão de todas as categorias de despesas operacionais (sem valores órfãos) e parcelas de dívidas não sincronizadas',
      'Precisão Contábil & Competência Dinâmica: exclusão de O.S. canceladas/não aprovadas e de funcionários inativos da folha/BI, taxas de cartão considerando somente taxas absorvidas pela empresa, saldo parcial em Contas a Receber e competência automática pelo mês/data atual'
    ],
    changes: [
      {
        category: 'Removido',
        description:
          'Removidos todos os dados pré-alimentados em mockData (funcionários, investimentos/setup, logs e usuários secundários), históricos fictícios de 2024/2025 no Dashboard, valores padrão artificiais no Simulador de Custos e Frota e botões de geração de dados de exemplo.'
      },
      {
        category: 'Corrigido',
        description:
          'DRE (Financeiro) totalmente reconciliado com a fonte única de verdade: exibe Serviços Brutos, Peças Brutas, (-) Descontos em O.S. e Vendas Diretas fechando exatamente na Receita Bruta; despesas operacionais divididas em grupos mutuamente exclusivos com linha dedicada a Outras Despesas Operacionais e parcelas de dívidas.'
      },
      {
        category: 'Corrigido',
        description:
          'Eliminadas divergências entre Dashboard, DRE, BI (Gráficos), Fechamento Contábil e Rentabilidade por Funcionário: comissões de funcionários agora entram no custo de pessoal do BI, O.S. canceladas e orçamentos pendentes não inflam receitas nem Contas a Receber, pagamentos parciais abatem o saldo devedor e taxas de cartão repassadas ao cliente não distorcem a margem.'
      },
      {
        category: 'Alterado',
        description:
          'Seletor de competência (Cabeçalho, Fechamento Contábil e Rentabilidade), datas padrão de lançamentos e calendários agora usam dinamicamente o mês e a data reais do sistema, além de migração única de limpeza total preservando configurações da empresa, taxas de cartão e conta admin.'
      }
    ]
  },
  {
    version: 'v2.7.14',
    date: '17/11/2026',
    title: 'Vendas & PDV Multiformas/Bandeiras, Exclusão com Senha, Cancelamento, Busca de Produtos, OS & Manual Completo',
    summary:
      'Atualização abrangente dos módulos de Vendas, PDV, Ordens de Serviço, Estoque, BI, Financeiro e Configurações, incluindo múltiplas formas de pagamento com bandeiras de cartão diferentes, exclusão protegida por senha de administrador/funcionário autorizado, cancelamento aberto, busca de produtos/serviços com limpeza de campos, integração automática de custos e atualização completa do Manual do Sistema.',
    highlights: [
      'PDV & Vendas com Múltiplas Formas e Bandeiras Diferentes: combine Dinheiro, PIX, Crédito (1x–12x) e Débito com bandeiras independentes por cartão e cálculo automático de taxas e líquido',
      'Segurança em Vendas & PDV: Cancelar Venda livre para operadores com acesso ao módulo (estorna estoque e preserva auditoria) e Excluir Venda protegido por senha do Administrador ou funcionário autorizado',
      'Tela de Vendas Ágil: busca ao vivo de produtos do estoque e serviços, exclusão livre de qualquer item deixando campos limpos, botão Cancelar Venda antes de adicionar e envio direto ao PDV para finalizar e receber',
      'Integração Total de Custos, Comboboxes & Organização: remuneração por tipo (Salário, Hora Trabalhada, Comissão), filtros em combobox no BI/Estoque/Cadastros, Status unificados nas O.S., Temas/Auditoria movidos para Configurações e Manual do Sistema 100% atualizado'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Múltiplas formas de pagamento com seleção independente de bandeira de cartão (Visa, Mastercard, Elo, Hipercard, Outra) e parcelas (1x a 12x) tanto no Checkout do PDV quanto na criação, edição e cobrança de Vendas.'
      },
      {
        category: 'Segurança',
        description:
          'Botão Excluir Venda no PDV e em Vendas protegido por senha: valida a Senha Mestra do PDV (Configurações → Empresa) ou a senha de Administrador / funcionário com permissão concedida pelo Administrador (Configurações → Usuários). Botão Cancelar Venda disponível para qualquer usuário com acesso ao módulo.'
      },
      {
        category: 'Adicionado',
        description:
          'Na tela de Vendas: busca dinâmica de produtos e serviços, exclusão individual ou em lote (Limpar Lista) deixando os campos limpos sem valores residuais, botão Cancelar Venda antes da inclusão e botão Enviar e Finalizar no PDV para abrir o checkout direto no caixa.'
      },
      {
        category: 'Corrigido',
        description:
          'Corrigida a busca e inclusão de produtos cadastrados em Ordens de Serviço e padronizados todos os status de OS entre painel principal, cards, técnico, portal do cliente e PDV.'
      },
      {
        category: 'Alterado',
        description:
          'Integração automática de folha salarial, horas trabalhadas, comissões, compras e custos recorrentes no Financeiro/DRE; seleção de remuneração de funcionários, filtros do BI, Central de Cadastros e Estoque organizados em comboboxes; menus de Tema e Logs/Auditoria movidos do topo para Configurações; Manual do Sistema atualizado com todos os fluxos.'
      }
    ]
  },
  {
    version: 'v2.7.13',
    date: '15/11/2026',
    title: 'Recibo de Pagamento Automático Integrado ao PDV, Vendas, O.S. e Financeiro',
    summary:
      'Implementação completa do módulo de emissão automática de Recibos de Pagamento com controle de quitação e saldo parcial/devedor, dados completos do cliente, vínculo explícito com a OS ou Venda Direta, visualização rápida em modal (Folha A4 e Térmico 80mm), impressão, download em PDF e compartilhamento direto por WhatsApp/Web Share.',
    highlights: [
      'Disparo Automático no Caixa/PDV, OS, Vendas e Contas a Receber ao confirmar pagamento à vista, entrada, parcela ou quitação',
      'Controle de Saldo & Carimbo Visual: destaca Valor Pago, Valor Total e Falta Restante em pagamentos parciais e exibe selo QUITADO / INTEGRALMENTE PAGO ao quitar',
      'Saída Multiformato & Persistência em Nuvem: modal A4 e Cupom Térmico 80mm, download em PDF real (A4/80mm), compartilhamento rápido e aba Recibos Emitidos no PDV sincronizada com Firestore'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Entidade PaymentReceipt com numeração sequencial (REC-YYYY-XXXX), dados completos do cliente (CPF/CNPJ, telefone e endereço), itens vinculados, formas de pagamento, operador/terminal e histórico acumulado de saldo sincronizados no Firestore (/paymentReceipts).'
      },
      {
        category: 'Adicionado',
        description:
          'Suporte nativo a Pagamento Parcial / Entrada e Liquidação de Parcela Programada no Checkout do PDV, na Cobrança de OS e na Cobrança de Vendas Diretas, mantendo o saldo pendente atualizado até a quitação total.'
      },
      {
        category: 'Adicionado',
        description:
          'Modal global PaymentReceiptModal com alternância entre Folha A4 e Impressora Térmica 80mm, impressão dedicada, geração real de PDF em A4 e 80mm, cópia/Web Share e envio formatado pelo WhatsApp.'
      }
    ]
  },
  {
    version: 'v2.7.12',
    date: '14/11/2026',
    title: 'Interface Mobile Enxuta — Ocultação de Elementos Administrativos e Secundários no Celular',
    summary:
      'Refinamento completo de responsividade para telas de celular (< 768px): ocultação de controles administrativos de retaguarda, colunas secundárias de tabelas, subtítulos extensos, rodapé técnico, importadores XML/CSV e ferramentas avançadas que não são relevantes para operação em campo ou balcão móvel, mantendo a experiência desktop 100% intacta.',
    highlights: [
      'Cabeçalho & Menu Mobile limpos: ocultação de trocador de perfil, paletas de tema, selos informativos e módulos administrativos de escritório (Fechamento Fiscal, Custos Iniciais, Central Cadastros, Operadoras de Cartão, Google Drive, Configurações e Ajuda) no celular',
      'Listagens & Tabelas enxutas no celular: colunas secundárias (CPF/CNPJ, Cidade/UF, Datas, Atacado, Cargo/Comissão, Credor/Categoria) ocultadas em telas pequenas para priorizar identificação, status, valor e ação rápida',
      'Financeiro, PDV, Vendas & BI Mobile: cards de apoio e filtros avançados de BI recolhidos por padrão no celular com botão único de expansão, preservando carregamento imediato dos indicadores e gráficos'
    ],
    changes: [
      {
        category: 'Alterado',
        description:
          'Header, Sidebar e SystemFooter: ocultados no celular seletores de tema/perfil, avatar redundante, subtítulos institucionais, status de nuvem, rodapé de versão e itens administrativos de desktop.'
      },
      {
        category: 'Alterado',
        description:
          'Listagens operacionais (Ordens de Serviço, Clientes, Fornecedores, Produtos, Vendas Diretas e Funcionários): ocultados botões em lote desktop (importação/exportação CSV e XML NF-e), seletores secundários de paginação e colunas acessórias em telas menores que 768px.'
      },
      {
        category: 'Alterado',
        description:
          'Dashboard, PDV, Financeiro (DRE/Receber/Pagar) e Gráficos & BI: ocultados textos descritivos longos, colunas percentuais/secundárias e caixas avançadas recolhidas por botão toggle no celular.'
      }
    ]
  },
  {
    version: 'v2.7.11',
    date: '14/11/2026',
    title: 'BI Financeiro Completo com Caixas de Filtros, Períodos e Seletor Global de Gráficos',
    summary:
      'Página Gráficos & Indicadores Gerenciais (BI) reformulada com caixas independentes de filtros de período (Dia, Semana, Quinzena, Mês, Trimestre, Semestre, Anual, Data Específica e Todo o Período), filtros por Cliente, Produto, Serviço, Canal e Situação, caixas de seleção dos dados exibidos, panorama financeiro completo com DRE executivo e seletor único do tipo de gráfico aplicado a todos os painéis selecionados.',
    highlights: [
      'Caixa de Período & Datas: ajuste dinâmico para Dia, Semana, Quinzena, Mês, Trimestre, Semestre, Anual, Data Específica (início/fim) e Todo o Período com rateio proporcional de folha e frota',
      'Caixa de Filtros por Entidade: recorte financeiro exato por Cliente, Produto/Peça, Serviço, Canal (O.S. vs PDV) e Situação (Pago vs Pendente)',
      'Caixa de Escolha de Dados & Seletor Global de Tipo de Gráfico: ative/desative os 7 blocos de indicadores e altere simultaneamente o formato de todos os gráficos selecionados (Colunas, Barras, Linha/Área, Rosca/Pizza ou Proporção 100%)'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Caixa 1 — Filtro de Período & Datas em AnalyticsChartsView com botões rápidos para Dia, Semana, Quinzena, Mês, Trimestre, Semestre, Anual, Data Específica (data inicial e final) e Todo o Período.'
      },
      {
        category: 'Adicionado',
        description:
          'Caixa 2 — Filtros por Cliente, Produto/Peça, Serviço, Canal de Origem e Situação Financeira, incluindo rateio proporcional de descontos e taxas de cartão nos itens filtrados.'
      },
      {
        category: 'Adicionado',
        description:
          'Caixa 3 — Seleção de Dados & Painéis com caixas marcáveis e atalhos rápidos (Marcar Tudo, Foco 100% Financeiro, Rankings) para controlar quais blocos aparecem no BI.'
      },
      {
        category: 'Adicionado',
        description:
          'Caixa 4 — Seletor Global de Tipo de Gráfico que define o modelo visual (Colunas Verticais, Barras Horizontais, Linha / Área, Rosca / Pizza ou Proporção 100%) para todos os gráficos selecionados de uma só vez.'
      },
      {
        category: 'Alterado',
        description:
          'Panorama Financeiro & DRE Executivo completo com 6 KPIs principais (Receita Bruta, Recebido, A Receber, Custos & Despesas, Contas a Pagar e Lucro Líquido) e demonstrativo linha a linha com percentuais sobre receita.'
      }
    ]
  },
  {
    version: 'v2.7.10',
    date: '14/11/2026',
    title: 'Foto do Produto no Hover, na Listagem e na Grade (Cards)',
    summary:
      'Adicionada exibição padronizada da foto do produto com fallback seguro no tooltip flutuante ao passar o mouse (hover), na coluna Foto das tabelas em listagem, nos cards de grade e no balcão do PDV.',
    highlights: [
      'Tooltip flutuante (RowHoverTooltip) atualizado para exibir a foto do produto ao passar o mouse sobre linhas, cards de grade, movimentações de estoque e itens do PDV',
      'Coluna Foto em linha única adicionada às tabelas de Produtos & Estoque e Cadastro Geral (Produtos & Peças)',
      'Cards de Grade ampliados com destaque visual para a foto do produto e suporte rápido para anexar foto também no Cadastro Geral'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Criado componente reutilizável ProductPhotoThumb com política anti-quebra (referrerPolicy="no-referrer" e fallback automático caso a imagem falhe ou ainda não exista foto cadastrada).'
      },
      {
        category: 'Adicionado',
        description:
          'Incluído suporte a foto de produto no card flutuante de hover (RowHoverTooltip) em Produtos & Estoque (listagem, grade e movimentações Kardex), Cadastro Geral (Produtos & Peças) e Balcão PDV.'
      },
      {
        category: 'Alterado',
        description:
          'Adicionada coluna Foto na listagem em tabela de produtos, ampliado o bloco de imagem nos cards em formato Grade e habilitado envio/URL de foto diretamente no modal de produto do Cadastro Geral.'
      }
    ]
  },
  {
    version: 'v2.7.9',
    date: '14/11/2026',
    title: 'Página de Gráficos & BI Interativos, Remoção de Blocos de Resumo nos Cadastros e Módulo Completo de Usuários',
    summary:
      'Removidos os blocos de indicadores de Clientes, Fornecedores e Quadro de Funcionários e criada a página dedicada de Gráficos & BI com múltiplos modelos visuais selecionáveis pelo usuário (Colunas, Barras, Linha/Área, Rosca/Pizza e Proporção), além da gestão completa de Usuários com alternância Listagem e Grade.',
    highlights: [
      'Remoção completa dos blocos de resumo em Clientes (Total, PJ, PF, Com OS em Aberto, Em atendimento), Fornecedores e Quadro de Funcionários',
      'Nova página Gráficos & BI no menu Financeiro consolidando indicadores de Clientes, Fornecedores, Folha de Funcionários e Financeiro/DRE',
      'Seletor global e por gráfico com 5 modelos visuais: Colunas Verticais, Barras Horizontais, Linha & Área, Rosca/Pizza e Comparativo Proporcional',
      'Módulo completo de Usuários com CRUD, Busca Dinâmica, tooltip no hover e alternância Listagem | Grade (Cards)'
    ],
    changes: [
      {
        category: 'Removido',
        description:
          'Removidos os indicadores "Total de Clientes", "Pessoa Jurídica (PJ)", "Pessoa Física (PF)", "Com OS em Aberto" e "Em atendimento" da tela de Clientes; "Total de Fornecedores", "Com Contas a Pagar", "Total em Aberto (Geral)" e "Linha Principal" da tela de Fornecedores; e "Custo Total de Folha Mensal", "Salários Base Nominais" e "Encargos & Benefícios (INSS/FGTS)" da tela de Quadro de Funcionários.'
      },
      {
        category: 'Adicionado',
        description:
          'Criada a página Gráficos & BI (AnalyticsChartsView) acessível no menu lateral Financeiro com filtros de competência (Mensal/Geral), gráficos de Clientes, Fornecedores, Folha Salarial, DRE Gerencial, Evolução Mensal, Receitas por Canal, Formas de Pagamento, Despesas Operacionais/Frota e Contas a Pagar, com alternância instantânea entre 5 modelos de gráficos.'
      },
      {
        category: 'Adicionado',
        description:
          'Implementado o módulo completo de Usuários (UsersManagementPanel) integrado em Cadastro Geral e Configurações do Sistema com persistência, ativação/inativação, Busca Dinâmica, modal (+) e alternância Listagem | Grade (Cards) alinhada às telas de Serviços, Produtos, Vendas, Clientes e Fornecedores.'
      }
    ]
  },
  {
    version: 'v2.7.8',
    date: '14/11/2026',
    title: 'Alternância Listagem/Grade (Cards), Tooltip de Descrição no Hover e Remoção dos Cards de Clientes',
    summary:
      'Removidos os cards superiores da tela de Cadastro de Clientes, adicionada a alternância padronizada entre Listagem e Grade (Cards) nas telas de cadastros/listagens do sistema e implementado card flutuante ao passar o mouse sobre qualquer linha de cadastro exibindo a descrição completa dos dados.',
    highlights: [
      'Remoção dos 4 cards de resumo superiores na tela de Cadastro de Clientes (ClientsView)',
      'Seletor global Listagem | Grade (<ViewModeToggle />) com layout em cards em Clientes, O.S., Vendas, Fornecedores, Produtos, Funcionários, Frota, Operadoras, Custos, Financeiro e Cadastro Geral',
      'Tooltip flutuante via Portal (<RowHoverTooltip />) exibindo a descrição completa dos dados ao passar o mouse sobre qualquer linha de cadastro'
    ],
    changes: [
      {
        category: 'Removido',
        description:
          'Removidos os cards superiores de métricas da tela de Cadastro de Clientes (Total de Clientes, Pessoa Jurídica, Pessoa Física e Com OS em Aberto).'
      },
      {
        category: 'Adicionado',
        description:
          'Criados os componentes globais <ViewModeToggle /> (Listagem | Grade) e useRowHoverTooltip / RowHoverTooltipPortal via Portal para exibir descrição e campos completos ao passar o mouse sobre as linhas sem corte por overflow.'
      },
      {
        category: 'Alterado',
        description:
          'Atualizadas as telas de Clientes, Ordens de Serviço, Vendas, Fornecedores, Produtos & Estoque, Funcionários, Frota, Operadoras de Cartão, Custos Operacionais, Financeiro e Cadastro Geral (todas as 7 abas) com alternância Listagem/Grade, cards responsivos e tooltip de descrição ao passar o mouse.'
      }
    ]
  },
  {
    version: 'v2.7.7',
    date: '14/11/2026',
    title: 'Alteração de Status e Data de Entrega dos Serviços na Tela de Ordens de Serviço',
    summary:
      'Adicionados controles completos na tela de Ordens de Serviço para alterar o status diretamente na listagem, na modal de detalhes (+), em modal rápida dedicada e no cadastro/edição da OS, com registro específico da Data de Entrega dos Serviços e Previsão de Entrega.',
    highlights: [
      'Seletor rápido de Status e botão da coluna Entrega Serviços diretamente na listagem em linha única de OS',
      'Modal rápida "Alterar Status & Entrega" ao concluir/finalizar ou clicar na data de entrega',
      'Painel inline de edição de Status, Previsão e Data de Entrega dentro da modal (+) de detalhes da OS',
      'Campos dedicados de Status, Previsão e Data de Entrega dos Serviços na modal de Nova/Editar OS e na ficha A4 impressa'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Adicionado seletor de alteração rápida de Status na tabela de Ordens de Serviço (ServiceOrdersView), coluna clicável "Entrega Serviços", filtros completos para todos os status (incluindo Aprovação, Aguardando Peças e Canceladas) e modal rápida "Alterar Status & Entrega" com botão "Hoje".'
      },
      {
        category: 'Adicionado',
        description:
          'Incluído editor de Status da OS, Previsão de Entrega e Data de Entrega dos Serviços na modal completa (+) da Ordem de Serviço e na modal de abertura/edição de OS.'
      },
      {
        category: 'Alterado',
        description:
          'Atualizados o modelo de impressão A4 (ServiceOrderPrintTemplate) e a exportação HTML de OS para exibirem a Data de Entrega dos Serviços no bloco Prazos e Responsável.'
      }
    ]
  },
  {
    version: 'v2.7.6',
    date: '14/11/2026',
    title: 'Listas Abreviadas em Linha Única com Botão (+) para Modal Completa de Dados',
    summary:
      'Reversão dos cartões empilhados, gavetas abaixo da linha e tooltips flutuantes (hover), padronizando todas as listagens do sistema no formato lista abreviada em linha única com botão (+) que abre todos os dados completos do registro em uma janela modal.',
    highlights: [
      'Remoção de tooltips flutuantes (hover), gavetas abaixo da linha e cards empilhados multi-linha',
      'Formato lista rigorosamente em 1 linha única (white-space: nowrap) com dados essenciais abreviados',
      'Botão (+) padronizado em cada registro abrindo a Modal Completa (<RecordDetailModal />) com todos os dados e ações',
      'Aplicado em Ordens de Serviço, Clientes, Produtos & Estoque, Vendas, Fornecedores, Equipe, Frota e Serviços'
    ],
    changes: [
      {
        category: 'Removido',
        description:
          'Removido o componente <RowHoverDetail />, removidas as gavetas expansíveis abaixo das linhas de O.S. (#os-drawer-*), removidos os blocos em cards empilhados (md:hidden) e eliminadas células com quebra de segunda linha nas tabelas.'
      },
      {
        category: 'Adicionado',
        description:
          'Criado componente global <RecordDetailModal /> (src/components/RecordDetailModal.tsx), classe .list-plus-btn em src/index.css e controlador Vanilla JS setupListDetailModals em src/utils/uiPatterns.ts.'
      },
      {
        category: 'Alterado',
        description:
          'Padronizadas todas as listagens em formato lista abreviada de linha única (.dense-table / .dense-row) com botão (+) abrindo todos os dados completos e ações rápidas em modal nas telas de Ordens de Serviço, Clientes, Produtos & Estoque, Vendas, Fornecedores e Cadastro Geral.'
      }
    ]
  },
  {
    version: 'v2.7.5',
    date: '14/11/2026',
    title: 'Padronização Global de Tabelas Compactas, Hover de Detalhes e O.S. em Linha Única Expansível (+)',
    summary:
      'Refatoração completa de UX/UI nas telas de Ordens de Serviço, Clientes, Produtos & Estoque, Vendas Diretas, Fornecedores e Equipe/Funcionários: tabelas densas compactas com card flutuante de detalhes ao passar o mouse (hover), listagem de O.S. em linha única com nome completo do cliente + card expansível (+), cards empilhados no mobile sem scroll horizontal e busca dinâmica em Vendas.',
    highlights: [
      'Ordens de Serviço em linha única compacta com nome completo do cliente sem cortes e botão card expansível (+)',
      'Gaveta expansível na própria linha da OS exibindo técnico, veículo, equipamento, serviços, peças, parcelas e ações rápidas',
      'Tabelas compactas (.dense-table) com card flutuante (<RowHoverDetail />) em Clientes, Produtos, Vendas, Fornecedores e Equipe',
      'Cards empilhados no mobile (< 768px) com área de toque >= 44px e campo LiveSearchInput no Histórico de Vendas'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Criado componente React <RowHoverDetail /> (src/components/RowHoverDetail.tsx) com React Portal seguro contra cortes de overflow, e utilitários modulares Vanilla JS setupExpandableServiceOrders e setupDenseRowTooltips (src/utils/uiPatterns.ts) com classes CSS padronizadas (.dense-table, .hover-detail-card, .os-compact-row, .os-expand-card-btn, .os-expanded-drawer, .os-mobile-stack).'
      },
      {
        category: 'Alterado',
        description:
          'Refatorada a listagem de Ordens de Serviço (ServiceOrdersView) para exibir estritamente 1 linha compacta por OS no desktop (ID curto, status, data, nome completo do cliente/responsável sem truncate, total e botão card +), além de cards empilhados responsivos no mobile com botão + >= 44px.'
      },
      {
        category: 'Alterado',
        description:
          'Compactadas as tabelas de Clientes (ClientsView), Produtos & Estoque (ProductsAndStockView), Vendas Diretas (SalesView), Fornecedores (SuppliersView) e Cadastro Geral / Equipe & Técnicos (MasterRegistrationsView), exibindo dados completos ao passar o mouse (hover) e cards empilhados no celular.'
      },
      {
        category: 'Adicionado',
        description:
          'Incluída barra de Busca Dinâmica (<LiveSearchInput />) diretamente no cabeçalho do Histórico de Vendas Faturadas (SalesView) para filtrar pedidos em tempo real por código, cliente ou vendedor.'
      }
    ]
  },
  {
    version: 'v2.7.4',
    date: '14/11/2026',
    title: 'Padronização Global de Busca Dinâmica em Tempo Real (Desktop e Mobile)',
    summary:
      'Implementação padronizada de Busca Dinâmica com Lista Suspensa (Autocomplete/Dropdown) em todos os campos de busca e pesquisa do sistema, com debounce de 300ms, ativação a partir de 2 caracteres, navegação completa por teclado e responsividade móvel travada ao viewport.',
    highlights: [
      'Componente global LiveSearchInput + utilitário modular Vanilla JS setupLiveSearch (.global-search-container)',
      'Ativação automática com >= 2 caracteres, debounce mínimo de 300ms e estado visual de carregamento (Buscando...)',
      'Navegação por teclado (ArrowDown, ArrowUp, Enter, Escape), fechamento ao clicar fora e destaque do termo buscado',
      'CSS mobile-first com largura segura (100% / max-width: calc(100vw - 1rem)), altura máxima 60vh e tap targets >= 44px'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Criado padrão global de estilos responsivos (.global-search-container, .search-modal, .search-item, .search-highlight) em src/index.css com z-index 1050, rolagem interna max-height: 60vh no mobile e áreas de toque mínimas de 48px-52px.'
      },
      {
        category: 'Adicionado',
        description:
          'Implementado utilitário framework-agnostic setupLiveSearch (src/utils/liveSearch.ts) com AbortController, debounce >= 300ms, cache de requisições, Escape/clique fora e template HTML reutilizável (LIVE_SEARCH_HTML_TEMPLATE).'
      },
      {
        category: 'Adicionado',
        description:
          'Criado componente React reutilizável LiveSearchInput (src/components/LiveSearchInput.tsx) com thumbnail, título destacado, subtítulo, preço/valor alinhado à direita e mensagem amigável de nenhum resultado encontrado.'
      },
      {
        category: 'Alterado',
        description:
          'Substituídos todos os campos de busca do sistema (PDV Balcão e Fila, Vendas Diretas, Produtos & Estoque, Clientes, Ordens de Serviço, Fornecedores, Financeiro, Painel do Técnico, Cadastro Geral, Google Agenda, Custos Iniciais, Manual, Ajuda, Google Drive e Busca XML Gmail) pelo padrão global LiveSearchInput, removendo overflow-hidden de containers pais para evitar cortes no dropdown.'
      }
    ]
  },
  {
    version: 'v2.7.3',
    date: '14/11/2026',
    title: 'Calculadora de Parcelas e Edição Individual de Pagamentos na Modal de OS',
    summary:
      'Atualização da modal de Ordem de Serviço para calcular automaticamente o total líquido e dividir entrada e parcelas com datas escalonadas, permitindo editar manualmente data, tipo (Entrada/Parcela/À Vista), forma de pagamento (ex: Dinheiro) e data específica de quitação em cada lançamento.',
    highlights: [
      'Calculadora automática de Entrada + divisão exata em parcelas com cálculo de taxas e líquido',
      'Edição individual de tipo (Entrada / Parcela / À Vista), data de vencimento, forma e valor por linha',
      'Marcação de status Pago com data específica de recebimento (ex: parcela em dinheiro paga em tal dia)',
      'Sincronização com impressão A4 da OS, exportação HTML e pré-carregamento no PDV Caixa'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Calculadora Automática de Entrada & Parcelamento na modal de Ordem de Serviço (ServiceOrdersView) com divisão exata em centavos, intervalo de dias configurável e pré-visualização instantânea.'
      },
      {
        category: 'Adicionado',
        description:
          'Editor individual por parcela permitindo alterar tipo (Entrada / Parcela / À Vista), forma de pagamento (PIX, Dinheiro, Cartão, Boleto, Faturado), data de vencimento, valor, observação e status Pago com campo de data específica de pagamento (paidAt).'
      },
      {
        category: 'Alterado',
        description:
          'Estendido o tipo PaymentSplit (src/types.ts), o comprovante de impressão A4 (ServiceOrderPrintTemplate), a exportação HTML e o checkout do PDV (PdvView) para refletirem valores já quitados em entrada/parcelas e as condições programadas.'
      }
    ]
  },
  {
    version: 'v2.7.2',
    date: '14/11/2026',
    title: 'Ampliação de 15% na Tipografia Global para Computador',
    summary:
      'Aumento proporcional de 15% em todos os textos do sistema exclusivamente para telas de computador (>= 1024px), melhorando a legibilidade sem alterar a visualização mobile nem a impressão A4.',
    highlights: [
      'Aumento global de +15% em títulos, rótulos, tabelas, campos e textos no desktop',
      'Preservação integral do layout responsivo no celular e da escala de impressão'
    ],
    changes: [
      {
        category: 'Alterado',
        description:
          'Aplicada escala tipográfica de +15% em todas as variáveis de tamanho de fonte (--text-xs até --text-5xl), texto base do corpo e classes de fonte fixa para visualização em telas de computador (@media screen and (min-width: 1024px)).'
      }
    ]
  },
  {
    version: 'v2.7.1',
    date: '14/11/2026',
    title: 'Atalho de Cadastro Rápido de Cliente (Modal) no PDV',
    summary:
      'Adicionado atalho direto no PDV (cabeçalho e Balcão PDV Rápido) para abrir janela modal de cadastro rápido de cliente, com definição de Varejista/Atacadista, consulta de CNPJ/CEP e seleção automática na venda.',
    highlights: [
      'Botão "Novo Cliente" no cabeçalho do PDV e botão "Cadastrar" ao lado da busca no Balcão PDV',
      'Cadastro rápido com escolha PF/PJ, perfil Varejista/Atacadista e busca automática de CNPJ e CEP',
      'Seleção automática do cliente recém-cadastrado e liberação imediata de atacado se Atacadista'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Atalho e janela modal "Cadastro Rápido de Cliente (PDV)" acessíveis pelo cabeçalho do PDV, pelo botão "Cadastrar" no carrinho e quando a busca não encontrar um cliente.'
      },
      {
        category: 'Alterado',
        description:
          'addClient no AppContext agora retorna o cliente recém-criado para selecioná-lo automaticamente no Balcão PDV Rápido logo após salvar.'
      }
    ]
  },
  {
    version: 'v2.7.0',
    date: '14/11/2026',
    title: 'Liberação de Preços de Atacado Exclusiva para Clientes Atacadistas',
    summary:
      'Inclusão da classificação comercial do cliente (Varejista ou Atacadista) em todos os cadastros e bloqueio automático da tabela de atacado no PDV e em Vendas Diretas até a busca e seleção de um cliente cadastrado como Atacadista.',
    highlights: [
      'Campo Tipo de Cliente (Varejista vs Atacadista) nos cadastros, filtros e importações',
      'Busca rápida de cliente por nome, CPF/CNPJ ou telefone no PDV e em Vendas Diretas',
      'Tabela Atacado bloqueada automaticamente para vendas balcão e clientes varejistas'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Adicionado o campo Tipo de Cliente (Varejista / Atacadista) no modelo Client, no Cadastro de Clientes (ClientsView), no Cadastro Geral (MasterRegistrationsView), na importação CSV/Universal, no schema Firebase e na exportação MySQL.'
      },
      {
        category: 'Adicionado',
        description:
          'Adicionado filtro por perfil comercial (Todos, Varejo, Atacado) e indicador visual na listagem de clientes.'
      },
      {
        category: 'Alterado',
        description:
          'No Balcão PDV Rápido (PdvView) e em Vendas Diretas (SalesView), adicionada busca rápida de clientes e bloqueio da tabela de Atacado enquanto um cliente cadastrado como Atacadista não for buscado e selecionado.'
      },
      {
        category: 'Corrigido',
        description:
          'Ao trocar de cliente atacadista para varejista ou consumidor balcão no PDV ou em Vendas, os preços do carrinho/itens são automaticamente revertidos para a tabela de Varejo.'
      }
    ]
  },
  {
    version: 'v2.6.4',
    date: '14/11/2026',
    title: 'Ajuste Tipográfico na Chamada da Tela de Login',
    summary:
      'Redução da escala de fonte de "Controle em tempo real." posicionando-o logo abaixo do título principal "Gestão completa." para maior destaque hierárquico.',
    highlights: [
      'Título principal "Gestão completa." em destaque acima de "Controle em tempo real."'
    ],
    changes: [
      {
        category: 'Alterado',
        description:
          'Diminuído o tamanho da fonte do texto "Controle em tempo real." e posicionado como subtítulo diretamente abaixo de "Gestão completa." na tela de login.'
      }
    ]
  },
  {
    version: 'v2.6.3',
    date: '14/11/2026',
    title: 'Limpeza Visual no Bloco de Marca da Tela de Login',
    summary:
      'Remoção da linha secundária com dado da empresa exibida abaixo do nome principal ao lado da logo na tela de login, mantendo o visual mais limpo.',
    highlights: [
      'Apenas logo e nome principal no cabeçalho de marca do login'
    ],
    changes: [
      {
        category: 'Removido',
        description:
          'Retirado o dado secundário da empresa (razão social) exibido abaixo do nome da empresa ao lado da logo na tela de login (LoginView).'
      }
    ]
  },
  {
    version: 'v2.6.2',
    date: '14/11/2026',
    title: 'Exibição de Endereço no Login & Detalhamento Completo de Mini-Alterações',
    summary:
      'Substituição do CNPJ pelo endereço completo cadastrado da empresa na tela de acesso e expansão do histórico de versões para registrar individualmente cada ajuste e correção aplicada ao sistema.',
    highlights: [
      'Endereço completo da empresa exibido na tela de login no lugar do CNPJ',
      'Histórico granular detalhando cada mini-alteração desde a v1.0.0 até a v2.6.2'
    ],
    changes: [
      {
        category: 'Alterado',
        description:
          'Removida a exibição do CNPJ na tela de login (LoginView), passando a mostrar o endereço completo cadastrado (rua, número, bairro, cidade/UF e CEP) junto ao telefone da empresa.'
      },
      {
        category: 'Adicionado',
        description:
          'Detalhadas todas as mini-alterações (patches v2.0.1, v2.0.2, v2.4.1, v2.4.2, v2.4.3, v2.6.1 e v2.6.2) no Changelog oficial e na aba Histórico de Versões dentro do sistema.'
      }
    ]
  },
  {
    version: 'v2.6.1',
    date: '14/11/2026',
    title: 'Redesign da Tela de Login (Fundo Azul Escuro, Fontes Maiores & Logo da Empresa)',
    summary:
      'Reformulação visual completa da tela de login inspirada em layout moderno de duas colunas com tema azul escuro, fontes ampliadas para melhor leitura e exibição da logo cadastrada da empresa.',
    highlights: [
      'Fundo em azul escuro com cartão translúcido dark',
      'Fontes ampliadas nos títulos, rótulos, campos e botões',
      'Logo da empresa cadastrada exibida ao lado do formulário'
    ],
    changes: [
      {
        category: 'Alterado',
        description:
          'Alterado o fundo da tela de login para azul escuro com gradiente suave e aplicado tema escuro de alto contraste no cartão de autenticação e nos campos de entrada.'
      },
      {
        category: 'Alterado',
        description:
          'Aumentado o tamanho das fontes da tela de login (título principal, subtítulo, cabeçalho do cartão, rótulos de usuário/senha, caixas de texto e botão de entrada).'
      },
      {
        category: 'Adicionado',
        description:
          'Layout dividido em duas colunas exibindo a logo cadastrada da empresa ao lado do cartão de login (com fallback elegante em monograma caso não haja imagem configurada).'
      },
      {
        category: 'Corrigido',
        description:
          'Substituído o alerta nativo de navegador em "Esqueceu a senha?" por aviso integrado dentro do próprio cartão de login.'
      }
    ]
  },
  {
    version: 'v2.6.0',
    date: '14/11/2026',
    title: 'Documentação Completa de Alterações & Alinhamento de Versionamento',
    summary:
      'Padronização semântica das versões do sistema desde a implantação inicial, criação do Changelog oficial, atualização do Manual do Sistema (com capítulo do PDV) e unificação da versão em todos os módulos.',
    highlights: [
      'Changelog oficial estruturado (CHANGELOG.md)',
      'Nova aba "Histórico de Versões" no Manual do Sistema',
      'Capítulo completo de PDV / Frente de Caixa no Manual'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Criado o arquivo CHANGELOG.md na raiz do projeto documentando todas as versões e evoluções cronológicas do GestãoPro ERP.'
      },
      {
        category: 'Adicionado',
        description:
          'Adicionada a aba interativa "Histórico de Versões & Changelog" em Ajuda & Manual com busca textual, filtro por tipo de alteração e exportação em Markdown/Impressão.'
      },
      {
        category: 'Adicionado',
        description:
          'Incluído o Capítulo 13 no Manual do Sistema detalhando o fluxo completo do PDV / Frente de Caixa.'
      },
      {
        category: 'Alterado',
        description:
          'Alinhado o versionamento em version.ts, package.json, rodapé, tela de login, barra lateral, especificação de arquitetura e modal de ajuda.'
      },
      {
        category: 'Alterado',
        description:
          'Atualizado o Capítulo 12 do Manual do Sistema removendo referências aos antigos botões de download JSON e .ZIP retirados da tela de Configurações.'
      }
    ]
  },
  {
    version: 'v2.5.0',
    date: '14/11/2026',
    title: 'Módulo PDV / Frente de Caixa & Baixa Unificada de Vendas e OS',
    summary:
      'Implantação do Ponto de Venda (PDV) completo para que todas as Vendas Diretas e Ordens de Serviço passem pelo caixa para conferência, baixa de valores recebidos, emissão de comprovante e fechamento de turno.',
    highlights: [
      'Abertura, Suprimento, Sangria e Fechamento de Caixa',
      'Fila unificada de recebimentos para OS e Vendas Diretas',
      'Balcão PDV Rápido com carrinho, desconto e busca por código de barras',
      'Pagamento único ou dividido (Multi-Split) com cálculo de troco e taxas'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Criada a tela dedicada "PDV / Caixa" (PdvView) acessível pelo menu lateral (OPERAÇÕES) e atalho rápido no cabeçalho superior, com contador dinâmico de títulos na fila.'
      },
      {
        category: 'Adicionado',
        description:
          'Implementado controle completo de sessões de caixa (CashRegisterSession) com Abertura de Caixa, seleção de terminal (Caixa 01, Caixa 02, Caixa 03, PDV Móvel) e fundo inicial de troco.'
      },
      {
        category: 'Adicionado',
        description:
          'Adicionadas operações de Suprimento e Sangria, extrato detalhado por forma de pagamento e Fechamento de Caixa com conferência entre saldo esperado e contado na gaveta.'
      },
      {
        category: 'Adicionado',
        description:
          'Criado modo "Balcão PDV Rápido" com tabela Varejo/Atacado, carrinho, descontos em R$/% e envio para fila ou liquidação imediata com baixa de estoque.'
      },
      {
        category: 'Adicionado',
        description:
          'Emissão de Comprovante de Caixa (cupom não fiscal) com código NSU, troco, formas de pagamento, impressão térmica e download em HTML.'
      },
      {
        category: 'Alterado',
        description:
          'Telas de Vendas Diretas e Ordens de Serviço integradas às ações reais do caixa (sendSaleToPdv, settleSaleInPdv, sendOrderToPdv, settleServiceOrderInPdv), sincronizadas em nuvem no Firestore.'
      }
    ]
  },
  {
    version: 'v2.4.3',
    date: '13/11/2026',
    title: 'Remoção de Backup JSON, Restauração e Download .ZIP em Configurações',
    summary:
      'Simplificação da tela de Configurações removendo ferramentas manuais de backup/restauração em JSON e download de código-fonte .ZIP.',
    highlights: [
      'Remoção de Download de Backup (JSON)',
      'Remoção de Restaurar de Arquivo de Backup e Código-Fonte (.ZIP)'
    ],
    changes: [
      {
        category: 'Removido',
        description:
          'Removidos da tela de Configurações os botões e painéis de Download de Backup (JSON), Restaurar de Arquivo de Backup e Código-Fonte & Arquivos (.ZIP).'
      }
    ]
  },
  {
    version: 'v2.4.2',
    date: '13/11/2026',
    title: 'Correção da Visibilidade de Produtos Cadastrados entre PC e Celular',
    summary:
      'Ajuste no motor de sincronização Firestore para garantir que todo produto cadastrado no computador apareça imediatamente no celular.',
    highlights: [
      'Higienização de propriedades undefined antes do envio ao Firestore',
      'Carga inicial e escuta contínua de produtos garantida em ambos os dispositivos'
    ],
    changes: [
      {
        category: 'Corrigido',
        description:
          'Corrigido problema em que produtos cadastrados no computador não apareciam no celular devido a campos opcionais undefined rejeitados pelo Firestore (aplicada função stripUndefined e listeners em tempo real).'
      }
    ]
  },
  {
    version: 'v2.4.1',
    date: '12/11/2026',
    title: 'Persistência da Tela Atual ao Atualizar o Navegador (F5 / Reload)',
    summary:
      'Garantia de permanência na mesma tela em uso quando o usuário recarrega ou atualiza o sistema.',
    highlights: [
      'Rota ativa preservada via hash (#aba) e localStorage'
    ],
    changes: [
      {
        category: 'Corrigido',
        description:
          'Corrigido comportamento que voltava para o Dashboard ao atualizar a página: o sistema agora salva a aba ativa na URL (#rota) e no localStorage, mantendo exatamente na mesma tela após atualização.'
      }
    ]
  },
  {
    version: 'v2.4.0',
    date: '12/11/2026',
    title: 'Sincronização em Tempo Real entre Computador e Celular',
    summary:
      'Implantação da sincronização em nuvem e entre abas para que computador e celular operem como o mesmo sistema espelhado.',
    highlights: [
      'Sincronização em tempo real via Firebase Firestore (onSnapshot)',
      'Espelhamento instantâneo entre abas locais via BroadcastChannel'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Implementada sincronização em nuvem (Firestore) para produtos, clientes, fornecedores, ordens de serviço e agendamentos, unificando a base visualizada no computador e no celular.'
      },
      {
        category: 'Adicionado',
        description:
          'Adicionado BroadcastChannel e listener de eventos storage para sincronização imediata entre múltiplas abas abertas.'
      }
    ]
  },
  {
    version: 'v2.3.0',
    date: '10/11/2026',
    title: 'Atualização Geral de Dependências & Remoção de Vulnerabilidades',
    summary:
      'Atualização completa dos pacotes do sistema para as versões mais atuais e eliminação de vulnerabilidades de segurança conhecidas.',
    highlights: [
      'Stack atualizada: React 19, Vite 8, TypeScript 7, Tailwind CSS 4 e Firebase 13',
      'Eliminação de vulnerabilidades em xlsx, express e @grpc/grpc-js'
    ],
    changes: [
      {
        category: 'Alterado',
        description:
          'Atualizadas todas as dependências do projeto para as versões mais atuais (React 19, Vite 8.3, @tailwindcss/vite 4.3, TypeScript 7.0, Firebase 13.2, jsPDF 4.2, lucide-react e @google/genai 2.4).'
      },
      {
        category: 'Segurança',
        description:
          'Removidas vulnerabilidades de dependências substituindo xlsx pelo pacote seguro @e965/xlsx, atualizando express e aplicando override seguro de @grpc/grpc-js.'
      }
    ]
  },
  {
    version: 'v2.2.0',
    date: '08/11/2026',
    title: 'Contagem de Páginas & Paginação em Produtos, OS, Clientes e Fornecedores',
    summary:
      'Adição de barra de paginação com contagem total de páginas e seletor de registros por página nas principais listagens cadastrais e operacionais.',
    highlights: [
      'Componente TablePagination com contagem "Página X de Y"',
      'Aplicado em Produtos, Ordens de Serviço, Clientes e Fornecedores'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Criado componente TablePagination exibindo página atual, contagem total de páginas, faixa de itens exibidos e seletor de itens por página.'
      },
      {
        category: 'Adicionado',
        description:
          'Adicionada a contagem e navegação de páginas nas telas de Produtos, Ordens de Serviço, Cadastro de Clientes e Cadastro de Fornecedores.'
      }
    ]
  },
  {
    version: 'v2.1.0',
    date: '05/11/2026',
    title: 'Detector Anti-Duplicidade de Uploads (XML NF-e e Demais Cadastros)',
    summary:
      'Identificação e sinalização automática ao tentar fazer upload do mesmo arquivo tanto em XML de NF-e quanto nos demais cadastros via upload.',
    highlights: [
      'Verificação SHA-256 + Chave NF-e (chNFe) + Número/CNPJ',
      'Alerta interativo antes de reprocessar arquivo repetido'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Implementado histórico e detector de arquivos duplicados por assinatura SHA-256, tamanho, nome e chave fiscal da NF-e.'
      },
      {
        category: 'Adicionado',
        description:
          'Sinalização visual imediata ao enviar arquivo XML de NF-e ou arquivo cadastral repetido na Central de Cadastros e na tela de Produtos, com opção de cancelar ou confirmar reprocessamento.'
      }
    ]
  },
  {
    version: 'v2.0.2',
    date: '02/11/2026',
    title: 'Compatibilidade & Exportação para Banco MySQL',
    summary:
      'Adequação do sistema para geração e exportação de estrutura e carga de dados compatível com banco de dados relacional MySQL.',
    highlights: [
      'Script .sql compatível com MySQL 5.7 / 8.0 e utf8mb4'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Adicionado gerador/exportador de script SQL completo compatível com MySQL 5.7 e 8.0 (tabelas, chaves e registros em utf8mb4) para integração com servidores MySQL.'
      }
    ]
  },
  {
    version: 'v2.0.1',
    date: '01/11/2026',
    title: 'Correção de Erro "auth/unauthorized-domain" & Tela de Validação Google Agenda/Drive',
    summary:
      'Correção do bloqueio de domínio não autorizado ao conectar o Google Agenda e Google Drive, com criação de tela dedicada para inserir e validar e-mail e credenciais.',
    highlights: [
      'Correção de Firebase: Error (auth/unauthorized-domain)',
      'Tela própria para entrada e validação de e-mail e senha/credenciais da Agenda'
    ],
    changes: [
      {
        category: 'Corrigido',
        description:
          'Corrigido erro "Firebase: Error (auth/unauthorized-domain)" ao clicar para conectar Google Agenda e Google Drive.'
      },
      {
        category: 'Adicionado',
        description:
          'Criado modal dedicado de entrada e validação de dados (e-mail e credenciais) para ligação direta e funcional com Google Agenda e Google Drive.'
      }
    ]
  },
  {
    version: 'v2.0.0',
    date: '30/10/2026',
    title: 'Integração Google Agenda & Google Drive',
    summary:
      'Lançamento dos módulos de agenda corporativa integrada ao Google Calendar e armazenamento/exportação via Google Drive.',
    highlights: [
      'Módulo Google Agenda integrado às Ordens de Serviço',
      'Módulo Google Drive para backup em nuvem'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Criado módulo Google Agenda com criação de agendamentos técnicos, vínculo automático com OS, endereço GPS e confirmação por WhatsApp.'
      },
      {
        category: 'Adicionado',
        description:
          'Criado módulo Google Drive para autenticação e envio de backups da base na nuvem.'
      }
    ]
  },
  {
    version: 'v1.5.0',
    date: '20/10/2026',
    title: 'Operadoras de Cartão, Leitor XML NF-e, WhatsApp & Temas Visuais',
    summary:
      'Expansão financeira e operacional com taxas de operadoras de 1x a 12x, importação de NF-e, comunicação direta via WhatsApp e personalização de temas.',
    highlights: [
      'Operadoras de cartão (PagBank, InfinitePay) com absorver/repassar taxa',
      'Leitura automática de XML de NF-e com atualização de custo e estoque',
      '6 templates integrados de mensagens para WhatsApp'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Cadastro de Operadoras de Cartão com taxas customizadas de Débito, Crédito à Vista e Parcelado (2x a 12x), além de conciliação de transações.'
      },
      {
        category: 'Adicionado',
        description:
          'Importador XML de NF-e com cadastro automático de fornecedor por CNPJ, recálculo de margem (55% Varejo / 35% Atacado) e lançamento em Contas a Pagar.'
      },
      {
        category: 'Adicionado',
        description:
          'Central de Importação Multi-Formato (CSV, XLSX, TXT, XML, PDF, SQL) e Modal WhatsApp com preenchimento dinâmico de variáveis.'
      },
      {
        category: 'Adicionado',
        description:
          'Seletor de 5 paletas de temas visuais no cabeçalho do sistema.'
      }
    ]
  },
  {
    version: 'v1.2.0',
    date: '10/10/2026',
    title: 'Portal do Cliente, Frota, Custos Iniciais (Break-Even) & Fechamento Fiscal',
    summary:
      'Introdução dos módulos gerenciais avançados: controle de frota e lucratividade por técnico, simulador de custos iniciais/dívidas, checklists com foto, assinatura touch e fechamento contábil PDF.',
    highlights: [
      'Checklists inteligentes com fotos de entrada/saída e assinatura digital touch',
      'Portal exclusivo do cliente com chamados e garantia por número de série',
      'Relatórios de Lucratividade por Técnico, Frota e Fechamento Fiscal PDF'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Checklists técnicos vinculados aos serviços, upload de fotos antes/depois, assinatura digital na tela e políticas de garantia parametrizáveis.'
      },
      {
        category: 'Adicionado',
        description:
          'Portal do Cliente com isolamento multi-tenant para acompanhamento de OS, garantias e abertura de chamados.'
      },
      {
        category: 'Adicionado',
        description:
          'Módulos de Frota & Veículos, Custos Fixos Operacionais, Custos Iniciais / Dívidas Parceladas com Simulador de Break-Even e Fechamento Contábil em PDF.'
      }
    ]
  },
  {
    version: 'v1.0.0',
    date: '01/10/2026',
    title: 'Lançamento Inicial do GestãoPro ERP',
    summary:
      'Base operacional completa para gestão de assistência técnica, vendas de peças/equipamentos, controle de estoque, financeiro e controle de acesso por perfis.',
    highlights: [
      'Ordens de Serviço, Orçamentos e Vendas Diretas',
      'Produtos/Estoque com movimentações Kardex, Clientes e Fornecedores',
      'Financeiro (Contas a Pagar/Receber + DRE Gerencial) e RBAC'
    ],
    changes: [
      {
        category: 'Adicionado',
        description:
          'Estrutura principal do ERP com Dashboard Gerencial, Ordens de Serviço, Vendas Diretas (Varejo/Atacado), Produtos & Estoque, Clientes, Fornecedores e Funcionários.'
      },
      {
        category: 'Adicionado',
        description:
          'Módulo Financeiro com Contas a Pagar, Contas a Receber e Demonstrativo de Resultado do Exercício (DRE) em tempo real.'
      },
      {
        category: 'Adicionado',
        description:
          'Autenticação com controle de permissões por perfil (Administrador, Colaborador, Vendedor, Técnico, Contador e Cliente) e Logs de Auditoria.'
      }
    ]
  }
];
