export const SYSTEM_VERSION = 'v2.7.22';
export const SYSTEM_BUILD = '2026.11.22';
export const SYSTEM_RELEASE_DATE = '22/11/2026';
export const SYSTEM_AUTHOR = 'HUGO GANDY';
export const SYSTEM_NAME = 'FIRE GESTÃO';
export const SYSTEM_FULL_NAME = 'FIRE GESTÃO - Sistema de Ordens de Serviço, PDV, Vendas e Financeiro';
