import React from 'react';
import { 
  FileSpreadsheet, 
  Printer, 
  Download, 
  Calendar, 
  Building, 
  DollarSign, 
  Percent, 
  ShieldCheck, 
  Layers,
  FileCheck,
  HardDrive,
  CheckCircle2
} from 'lucide-react';
import { useApp, formatBRL } from '../context/AppContext';
import { getAccessToken, googleSignIn } from '../services/googleAuthService';
import { uploadTextToDrive } from '../services/googleDriveService';
import {
  getAvailableMonths,
  getMonthLabelBR,
  isServiceOrderFinishedForDRE
} from '../utils/financialHelpers';

export const AccountingClosingView: React.FC = () => {
  const [driveLoading, setDriveLoading] = React.useState(false);
  const [driveFeedback, setDriveFeedback] = React.useState<string | null>(null);

  const { 
    selectedMonthYear, 
    setSelectedMonthYear, 
    serviceOrders, 
    directSales, 
    generalExpenses, 
    monthlyFinancialSummary,
    companySettings 
  } = useApp();

  const availableMonths = React.useMemo(
    () =>
      getAvailableMonths(selectedMonthYear, [
        ...serviceOrders.map(o => o.completionDate || o.openDate),
        ...directSales.map(s => s.date),
        ...generalExpenses.map(e => e.dueDate)
      ]),
    [selectedMonthYear, serviceOrders, directSales, generalExpenses]
  );

  const monthOrders = serviceOrders.filter(o => {
    const d = o.completionDate || o.openDate;
    return d.startsWith(selectedMonthYear) && isServiceOrderFinishedForDRE(o);
  });

  const monthSales = directSales.filter(s => s.date.startsWith(selectedMonthYear) && s.status !== 'cancelada');

  // Segregação tributária 100% alinhada com o DRE Oficial (sem receita negativa de serviços)
  const grossServicesRevenue = monthlyFinancialSummary.ordersServicesRevenue;
  const grossPartsRevenue = monthlyFinancialSummary.ordersPartsRevenue;
  const grossDirectSalesRevenue = monthlyFinancialSummary.salesRevenue;
  const totalGoodsRevenue = Number((grossPartsRevenue + grossDirectSalesRevenue).toFixed(2));
  const totalGrossBilling = monthlyFinancialSummary.totalRevenue;

  // Compras de Mercadorias & XMLs de Entrada no mês
  const purchasesXml = generalExpenses.filter(
    e =>
      (e.category === 'compra_produtos_xml' || e.category === 'compra_materiais') &&
      e.dueDate.startsWith(selectedMonthYear)
  );
  const totalPurchasesCost = purchasesXml.reduce((a, b) => a + Number(b.cost || 0), 0);

  // Taxas de operadoras absorvidas pela empresa no mês (alinhado ao DRE)
  const totalCardFees = monthlyFinancialSummary.totalCardFees;

  // Estimativa Simples Nacional (Anexo III Serviços 6,0% | Anexo I Comércio 4,0%)
  const estimatedTaxServices = Number((grossServicesRevenue * 0.06).toFixed(2));
  const estimatedTaxGoods = Number((totalGoodsRevenue * 0.04).toFixed(2));
  const totalEstimatedTaxes = Number((estimatedTaxServices + estimatedTaxGoods).toFixed(2));
  const effectiveTaxRatePercent = totalGrossBilling > 0 ? (totalEstimatedTaxes / totalGrossBilling) * 100 : 0;

  const handleSaveToDrive = async () => {
    setDriveLoading(true);
    setDriveFeedback(null);
    try {
      let token = await getAccessToken();
      if (!token) {
        const authRes = await googleSignIn();
        token = authRes?.accessToken || null;
      }
      if (!token) throw new Error('Conexão com Google Drive necessária.');

      const content = `
========================================================================
FECHAMENTO CONTÁBIL & FISCAL - ${companySettings.companyName || companySettings.tradeName || 'EMPRESA'}
========================================================================
CNPJ: ${companySettings.cnpj || 'Não informado'}
Competência: ${selectedMonthYear}
Emissão: ${new Date().toLocaleString('pt-BR')}
------------------------------------------------------------------------
1. SEGREGAÇÃO DO FATURAMENTO BRUTO
- Serviços Prestados (NFS-e / ISS): ${formatBRL(grossServicesRevenue)}
- Venda de Peças e Mercadorias (NF-e / ICMS): ${formatBRL(totalGoodsRevenue)}
- FATURAMENTO BRUTO TOTAL: ${formatBRL(totalGrossBilling)}

2. QUANTIDADE DE OPERAÇÕES NO MÊS
- Ordens de Serviço Faturadas: ${monthOrders.length}
- Vendas Diretas de Balcão: ${monthSales.length}

3. TRIBUTOS ESTIMADOS (DAS - SIMPLES NACIONAL)
- Serviços (Anexo III ~6%): ${formatBRL(estimatedTaxServices)}
- Comércio (Anexo I ~4%): ${formatBRL(estimatedTaxGoods)}
- TOTAL ESTIMADO: ${formatBRL(totalEstimatedTaxes)}

4. TAXAS DE CARTÃO DEDUZIDAS: ${formatBRL(totalCardFees)}
5. COMPRAS DE FORNECEDORES (XML): ${formatBRL(totalPurchasesCost)}
========================================================================
Salvo automaticamente via Google Drive pelo FIRE GESTÃO.
`;

      const fileName = `Fechamento_Contabil_${selectedMonthYear}_${(companySettings.tradeName || 'Empresa').replace(/\s+/g, '_')}.txt`;
      await uploadTextToDrive(token, fileName, content, 'text/plain');
      setDriveFeedback(`Salvo com sucesso no Google Drive: ${fileName}`);
      setTimeout(() => setDriveFeedback(null), 5000);
    } catch (err: any) {
      console.error('Erro ao salvar no Drive:', err);
      alert(err.message || 'Falha ao salvar no Google Drive.');
    } finally {
      setDriveLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div className="flex items-center gap-3.5">
          {companySettings.logoUrl && (
            <img 
              src={companySettings.logoUrl} 
              alt={companySettings.tradeName || 'Logo'} 
              className="max-h-12 max-w-[130px] object-contain rounded shrink-0 border border-slate-200 p-0.5 bg-white" 
            />
          )}
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-slate-900 tracking-tight">
                Relatório de Fechamento Mensal para o Contador
              </h1>
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                Espelho Fiscal & Contábil
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {companySettings.tradeName || companySettings.companyName || 'FIRE GESTÃO'} · Consolidação das notas fiscais, faturamento tributável (Serviços vs Comércio) e deduções fiscais.
            </p>
          </div>
        </div>

        <div className="no-print flex flex-wrap items-center gap-2.5">
          <div className="flex items-center gap-1.5 bg-white border border-slate-300 rounded-lg px-3 py-1.5 shadow-xs">
            <Calendar className="w-4 h-4 text-slate-400" />
            <select
              value={selectedMonthYear}
              onChange={(e) => setSelectedMonthYear(e.target.value)}
              className="text-xs font-semibold text-slate-700 bg-transparent border-0 focus:ring-0 cursor-pointer"
            >
              {availableMonths.map(m => (
                <option key={m.value} value={m.value}>
                  {m.label}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={handleSaveToDrive}
            disabled={driveLoading}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg shadow-xs cursor-pointer disabled:opacity-50"
            title="Salvar espelho fiscal diretamente no Google Drive"
          >
            <HardDrive className="w-3.5 h-3.5 text-blue-600" />
            <span>{driveLoading ? 'Salvando...' : 'Salvar no Google Drive'}</span>
          </button>

          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Imprimir / Exportar PDF Contábil</span>
          </button>
        </div>
      </div>

      {driveFeedback && (
        <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{driveFeedback}</span>
        </div>
      )}

      {/* Main Printable Accounting Document */}
      <div className="bg-white border border-slate-200 rounded-2xl p-8 shadow-xs space-y-6 text-xs text-slate-800">
        {/* Header Letterhead */}
        <div className="flex flex-col sm:flex-row justify-between items-start border-b-2 border-slate-900 pb-4 gap-4">
          <div className="flex items-start gap-4">
            {companySettings.logoUrl && (
              <img
                src={companySettings.logoUrl}
                alt={companySettings.tradeName || companySettings.companyName || 'Logo'}
                className="w-16 h-16 object-contain rounded-lg border border-slate-200 bg-white p-1 shrink-0"
              />
            )}
            <div>
              <div className="text-lg font-black tracking-tight text-slate-900 uppercase">
                {companySettings.companyName || companySettings.tradeName || 'EMPRESA NÃO CADASTRADA'}
              </div>
              {companySettings.tradeName && companySettings.tradeName !== companySettings.companyName && (
                <div className="text-xs font-semibold text-slate-700">
                  Nome Fantasia: {companySettings.tradeName}
                </div>
              )}
              <div className="text-[11px] text-slate-600 mt-0.5">
                CNPJ: <strong className="font-mono">{companySettings.cnpj || 'Não informado'}</strong>
                {companySettings.im ? <span> · Inscrição Municipal (ISS): <strong className="font-mono">{companySettings.im}</strong></span> : ''}
                {companySettings.ie ? <span> · Inscrição Estadual (ICMS): <strong className="font-mono">{companySettings.ie}</strong></span> : ''}
              </div>
              <div className="text-[11px] text-slate-600">
                Enquadramento: <strong>{companySettings.taxRegime === 'simples_nacional' ? 'Simples Nacional' : companySettings.taxRegime === 'lucro_presumido' ? 'Lucro Presumido' : companySettings.taxRegime === 'lucro_real' ? 'Lucro Real' : companySettings.taxRegime === 'mei' ? 'Microempreendedor Individual (MEI)' : 'Simples Nacional'}</strong>
                {companySettings.street ? (
                  <span> · {companySettings.street}, {companySettings.number || 'S/N'}{companySettings.neighborhood ? ` - ${companySettings.neighborhood}` : ''}, {companySettings.city || ''}/{companySettings.state || ''}</span>
                ) : ''}
              </div>
              {(companySettings.phone || companySettings.email) && (
                <div className="text-[11px] text-slate-500">
                  {companySettings.phone ? <span>Telefone: {companySettings.phone}</span> : ''}
                  {companySettings.phone && companySettings.email ? ' · ' : ''}
                  {companySettings.email ? <span>E-mail: {companySettings.email}</span> : ''}
                </div>
              )}
            </div>
          </div>

          <div className="text-right shrink-0">
            <div className="text-base font-bold font-mono text-blue-700">
              FECHAMENTO CONTÁBIL
            </div>
            <div className="text-xs font-semibold text-slate-700 mt-0.5">
              Competência: {getMonthLabelBR(selectedMonthYear)}
            </div>
            <div className="text-[10px] text-slate-400">
              Emissão: {new Date().toLocaleDateString('pt-BR')}
            </div>
          </div>
        </div>

        {/* 1. Resumo do Faturamento Bruto por Segregação Tributária */}
        <div className="space-y-2">
          <h2 className="font-bold text-xs uppercase tracking-wider text-slate-900 flex items-center gap-1.5 border-b pb-1">
            <span className="w-2 h-2 rounded-full bg-blue-600"></span>
            1. Segregação do Faturamento Bruto (Base de Cálculo Tributária)
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-[11px] text-slate-500">Prestação de Serviços (NFS-e / ISS)</span>
              <div className="text-lg font-bold font-mono text-slate-900 mt-1">{formatBRL(grossServicesRevenue)}</div>
              <div className="text-[10px] text-slate-400 mt-0.5">Mão de obra e taxas de visita em OS</div>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-[11px] text-slate-500">Comércio / Venda de Peças (NF-e / ICMS)</span>
              <div className="text-lg font-bold font-mono text-slate-900 mt-1">{formatBRL(totalGoodsRevenue)}</div>
              <div className="text-[10px] text-slate-400 mt-0.5">Peças aplicadas em OS + Vendas de Balcão</div>
            </div>

            <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-200">
              <span className="text-[11px] text-blue-800 font-semibold">Faturamento Bruto Total do Mês</span>
              <div className="text-lg font-black font-mono text-blue-900 mt-1">{formatBRL(totalGrossBilling)}</div>
              <div className="text-[10px] text-blue-700 mt-0.5">{monthOrders.length} OS + {monthSales.length} Vendas Faturadas</div>
            </div>
          </div>
        </div>

        {/* 2. Provisão de Impostos do Simples Nacional */}
        <div className="space-y-2">
          <h2 className="font-bold text-xs uppercase tracking-wider text-slate-900 flex items-center gap-1.5 border-b pb-1">
            <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
            2. Estimativa de Tributos a Recolher (DAS - Simples Nacional)
          </h2>

          <table className="w-full text-left border border-slate-200 rounded-lg overflow-hidden">
            <thead className="bg-slate-50 text-slate-700">
              <tr>
                <th className="p-2">Anexo / Fator Tributário</th>
                <th className="p-2 text-right">Base de Cálculo</th>
                <th className="p-2 text-center">Alíquota Efetiva Est.</th>
                <th className="p-2 text-right">Valor do Tributo</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              <tr>
                <td className="p-2 font-sans">Anexo III - Serviços de Manutenção e Assistência Técnica</td>
                <td className="p-2 text-right">{formatBRL(grossServicesRevenue)}</td>
                <td className="p-2 text-center">6,00%</td>
                <td className="p-2 text-right text-slate-900 font-bold">{formatBRL(estimatedTaxServices)}</td>
              </tr>
              <tr>
                <td className="p-2 font-sans">Anexo I - Comércio de Reservatórios Térmicos e Peças</td>
                <td className="p-2 text-right">{formatBRL(totalGoodsRevenue)}</td>
                <td className="p-2 text-center">4,00%</td>
                <td className="p-2 text-right text-slate-900 font-bold">{formatBRL(estimatedTaxGoods)}</td>
              </tr>
              <tr className="bg-slate-100 font-bold">
                <td className="p-2 font-sans">TOTAL DAS / IMPOSTOS ESTIMADOS DO MÊS</td>
                <td className="p-2 text-right">{formatBRL(totalGrossBilling)}</td>
                <td className="p-2 text-center">
                  {effectiveTaxRatePercent.toFixed(2).replace('.', ',')}% Efetiva
                </td>
                <td className="p-2 text-right text-rose-700">{formatBRL(totalEstimatedTaxes)}</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* 3. Deduções de Taxas de Cartão de Crédito e Débito */}
        <div className="space-y-2">
          <h2 className="font-bold text-xs uppercase tracking-wider text-slate-900 flex items-center gap-1.5 border-b pb-1">
            <span className="w-2 h-2 rounded-full bg-amber-600"></span>
            3. Taxas de Intermediação Financeira (Maquininhas de Cartão)
          </h2>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between font-mono">
            <div>
              <span className="font-sans font-medium text-slate-700">Total de Taxas Retidas pelas Credenciadoras (Visa/Master/Elo):</span>
              <div className="text-[11px] text-slate-400 font-sans mt-0.5">Dedução financeira não estornável para conciliação contábil</div>
            </div>
            <div className="text-base font-bold text-rose-700">{formatBRL(totalCardFees)}</div>
          </div>
        </div>

        {/* 4. Compras de Fornecedores / XMLs de Entrada */}
        <div className="space-y-2">
          <h2 className="font-bold text-xs uppercase tracking-wider text-slate-900 flex items-center gap-1.5 border-b pb-1">
            <span className="w-2 h-2 rounded-full bg-purple-600"></span>
            4. Resumo de Compras de Mercadorias para Revenda (NF-e Importadas)
          </h2>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between font-mono">
            <div>
              <span className="font-sans font-medium text-slate-700">Total de Entradas Fiscais no Mês:</span>
              <div className="text-[11px] text-slate-400 font-sans mt-0.5">{purchasesXml.length} notas fiscais importadas via arquivo XML</div>
            </div>
            <div className="text-base font-bold text-slate-900">{formatBRL(totalPurchasesCost)}</div>
          </div>
        </div>

        {/* 5. Folha de Pagamento & Encargos */}
        <div className="space-y-2">
          <h2 className="font-bold text-xs uppercase tracking-wider text-slate-900 flex items-center gap-1.5 border-b pb-1">
            <span className="w-2 h-2 rounded-full bg-indigo-600"></span>
            5. Despesas com Pessoal & Provisões Trabalhistas
          </h2>

          <div className="grid grid-cols-3 gap-3 font-mono">
            <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-[10px] text-slate-500 font-sans">Salários / Horas Nominais (Ativos):</span>
              <div className="font-bold text-slate-900">{formatBRL(monthlyFinancialSummary.baseSalaries)}</div>
            </div>
            <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-[10px] text-slate-500 font-sans">Encargos Sociais (Ativos):</span>
              <div className="font-bold text-slate-900">{formatBRL(monthlyFinancialSummary.benefitsCharges)}</div>
            </div>
            <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-[10px] text-slate-500 font-sans">Comissões Apuradas:</span>
              <div className="font-bold text-blue-700">{formatBRL(monthlyFinancialSummary.commissions)}</div>
            </div>
          </div>
        </div>

        {/* Signatures */}
        <div className="pt-10 grid grid-cols-2 gap-10 border-t border-slate-200 text-center text-xs">
          <div>
            <div className="border-t border-slate-400 pt-2 font-bold text-slate-900">
              {companySettings.companyName || companySettings.tradeName || 'Administração da Empresa'}
            </div>
            <div className="text-[10px] text-slate-500">
              Responsável pela Administração {companySettings.cnpj ? `· CNPJ: ${companySettings.cnpj}` : ''}
            </div>
          </div>

          <div>
            <div className="border-t border-slate-400 pt-2 font-bold text-slate-900">
              Contabilidade Responsável
            </div>
            <div className="text-[10px] text-slate-400">Contador Responsável / CRC Ativo</div>
          </div>
        </div>
      </div>
    </div>
  );
};
